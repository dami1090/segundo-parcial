#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "tramite.h"
#include "utn.h"

int main()
{
    void* aux;
    int auxInt;
    char seguir='s';
    int opcion=0;
    int i;
    int resp;

    eCliente* cliente;
    ArrayList* listaRegular;
    ArrayList* listaUrgente;
    FILE* archRegistro;
    listaRegular=al_newArrayList();
    listaUrgente=al_newArrayList();
    if(listaRegular!=NULL && listaUrgente!=NULL)
    {

    while(seguir=='s')
    {
        printf("1- ingresar reclamo\n");
        printf("2- solicitar turno urgente\n");
        printf("3- solicitar turno  regular\n");
        printf("4- \n");
        printf("5- \n");
        printf("6- \n");
        printf("7- Salir\n");


        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            auxInt=altaReclamo(listaRegular,listaUrgente);
            if(auxInt!=1)
            {
                printf("no se pudo guardar el reclamo\n");

            }
            else
            {
                printf("el reclamo se cargo satisfactoriamente\n");
            }
            system("pause");
            system("cls");
            break;
        case 2:
            auxInt=Urgente(listaUrgente);

            break;
        case 3:
            auxInt=Regular(listaRegular);
            break;
        case 4:
            break;
        case 5:
            break;
        case 6:
            guardarCvs(listaUrgente,listaRegular,char destino[]);
            break;

             case 7:
                seguir = 'n';
                break;
            default:
                printf("opcion invalida  \n");
                system("pause");
                system("cls");
                break;
            }
        }
    }
    else
    {
        printf("no hay espacio en memoria");

    }
        return 0;
    }

