struct
 {
 char* DNI;
 int turno;// cadena string dinamico,lo guardo en un buffer y dsp le hago un len , lo genero cn un malloc;
 int urgente;// 0 no 1 si;
 int regular;
 int activo;// 0 atendido 1 esperando
 }typedef eCliente;

 int altaReclamo(ArrayList* listaR,ArrayList* listaU);
 int Urgente(ArrayList* listaU);
 int Regular(ArrayList* listaR);
 int guardarCvs(ArrayList* lista,char destino[]);
