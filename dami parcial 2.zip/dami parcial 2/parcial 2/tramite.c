#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "tramite.h"
#include "utn.h"
/*
int parserCliente(FILE* pFile, ArrayList* pArrayListCliente)
{
    int aux=0;
    char auxDNI[50],auxTurno[50],auxUrgente[50],auxRegular[50],auxActivo[50];
    eCliente* cliente;

    fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxDNI,auxTurno,auxUrgente,auxRegular,auxActivo);
    while(!feof(pFile))
    {
        cliente=cliente_new();
        if(cliente!=NULL)
        {


            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",auxDNI,auxTurno,auxUrgente,auxRegular,auxActivo);
            cliente->DNI=atoi(auxDNI);
            cliente->turno=atoi(auxTurno);
            cliente->urgente=atoi(auxUrgente);
            cliente->regular=atoi(auxRegular);
            cliente->activo=atoi(auxActivo);


            pArrayListCliente->add(pArrayListCliente,cliente);
        }


        else
        {
            aux=-1;
        }
        return aux;
    }
}*/
eCliente* cliente_new(void)
{
    eCliente* returnAux = (eCliente*)calloc(1,sizeof(eCliente));

    return returnAux;
}
void cliente_print(eCliente* lista)
{
    printf("%d--%d--%d--%d--%d\n",lista->DNI,lista->turno,lista->urgente,lista->regular,lista->activo);
}

int altaReclamo(ArrayList* listaR,ArrayList* listaU)
{
    eCliente* cliente;
    int bandera;
    int auxResp;
    int retorno =-1;
    char auxDNI[100];
    char resp;
    int turnoU;
    int turnoR;




    printf("\ningrese DNI para dar de alta el reclamo\n");
    fflush(stdin);
    gets(auxDNI);

    printf("%s\n",auxDNI);
    resp = getChar("el DNI es correcto? s/n\n");
    if(resp != 's')
    {

        printf("reintentar operacion");
        return retorno;

    }
    else
    {

        printf("su tramite es de caracter (1)Urgente o (2)regular?\n");
        scanf("%d",&auxResp);
        if(auxResp==1)
        {
            cliente=cliente_new();
            if(cliente!=NULL)
            {
                turnoU++;
                cliente->DNI=atoi(auxDNI);
                cliente->turno=0;
                cliente->urgente=1;
                cliente->regular=0;
                cliente->activo=1;
                listaU->add(listaU,cliente);
                bandera=1;
                printf("su turno es: %d\n",turnoU);

            }

        }
        else if(auxResp==2)
        {
            cliente=cliente_new();
            if(cliente!=NULL)
            {
                turnoR++;
                cliente->DNI=atoi(auxDNI);
                cliente->turno=0;
                cliente->urgente=0;
                cliente->regular=1;
                cliente->activo=1;
                listaR->add(listaR,cliente);
                bandera=1;


            }
        }


    }
    if(bandera==1)
    {


        retorno=1;
    }
    return retorno;
}

int Urgente(ArrayList* listaU)
{
    void* aux;
    int turno;
    int retorno =-1;
    if(listaU !=NULL)
    {
        turno=listaU->len(listaU);
        printf(" Su turno de caracter Urgente:%d\n",turno);
        aux=(eCliente*)listaU->get(listaU,turno);
        aux->turno=turno;
        listaU->set(listaU,turno,aux);
        retorno=0;

    }
return retorno;
}

int Regular(ArrayList* listaR)
{
    void* aux;
    int turno;
    int retorno =-1;
    if(listaR !=NULL)
    {
        turno=listaR->len(listaR);
        printf(" Su turno de caracter REGULAR:%d\n",turno);
        aux=(eCliente*)listaR->get(listaR,turno);
        aux->turno=turno;
        listaR->set(listaR,turno,aux);
        retorno=0;

    }
return retorno;
}

int guardarCvs(ArrayList* listaR,ArrayList* listaU,char destino[])
{
    int aux=0;
    int i;

    eCliente* cliente;
    FILE* r;
    FILE* u;

    r=fopen(destino,"w");
    if(r != NULL)
    {
        fprintf(r,"%s,%s,%s,%s,%s,\n","DNI","turno","Urgente","Regular","Activo" );
        for(i=0;listar->len(listar);i++)
        {
           cliente=listar->get(listar,i);
            if((cliente->activo)==1 && (cliente->regular)==1)
            {

            fprintf(r,"%s,%d,%d,%d,%d\n",cliente->DNI,cliente->turno,cliente->urgente,cliente->regular,cliente->activo);
            }
        }
        fclose(r);
    }
    else
    {
        aux=-1;
    }
    u=fopen(destino,"w");
    if(u != NULL)
    {
        fprintf(u,"%s,%s,%s,%s,%s,\n","DNI","turno","Urgente","Regular","Activo" );
        for(i=0;listau->len(listau);i++)
        {
           cliente=listau->get(listau,i);
            if((cliente->activo)==1 && (cliente->urgente)==1)
            {

            fprintf(u,"%s,%d,%d,%d,%d\n",cliente->DNI,cliente->turno,cliente->urgente,cliente->regular,cliente->activo);
            }
        }
        fclose(u);
    }
    else
    {
        aux=-1;
    }
    return aux;
}
